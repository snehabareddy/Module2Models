package com.capgemini.TransportTruck.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.exception.TransportTruckException;
import com.capgemini.TransportTruck.service.ITruckDeatilsService;
import com.capgemini.TransportTruck.service.TruckDeatilsServiceImpl;
import com.capgemini.TransportTruck.service.Validator;



public class Client {
	
	private static Scanner scanner=new Scanner(System.in);
	private static TruckDetails customer = new TruckDetails();
		private static ITruckDeatilsService orderService = new TruckDeatilsServiceImpl();
		//private static ICustomerService customerService = new CustomerService();
		private static Validator validator = new Validator();

	public static void main(String[] args) throws  TransportTruckException{
		
		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Transport truck Booking System  ");
			System.out.println("_______________________________\n");


			System.out.println("1.Book Trucks");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			

			try {
				Integer option = scanner.nextInt();
				switch (option) {
				case 1:
					System.out.println("Enter customer Id:");
					String custId = scanner.next();
					if(validator.isValidCustomerId(custId)){
					System.out.println("Types of Trucks Available: ");
					List<TruckDetails> truckDetails=orderService.getTruckDetails();
					Iterator<TruckDetails> iterator= truckDetails.iterator();
					while(iterator.hasNext()){
						System.out.println(iterator.next());
					} 
					//Long truckId= orderService.placeOrder(customerId, totalPrice,quantity);
					System.out.println("Enter the truckId from above available truck details");
					Integer truckId=null;
					try{
					 truckId = scanner.nextInt();
					}catch(InputMismatchException e){
						System.out.println("Enter valid id");
						scanner.next();
					}
					if(orderService.isValidId(truckId)){
											
					System.out.println("Enter the number of trucks to be booked");
					Integer noOfTrucks = scanner.nextInt();
					Integer trucksAvail = orderService.trucksAvailable(truckId);
					if(noOfTrucks<trucksAvail){
						System.out.println("Enter customer mobile number");
						Long phnnumber = scanner.nextLong();
						if(validator.isValidCustomerMobile(phnnumber)){
							System.out.println("Enter the date of transportation");
							String date = scanner.next();
							DateFormat dateformat = new SimpleDateFormat("dd/MM/YYYY");
							java.util.Date udate = dateformat.parse(date);
							java.sql.Date hdate = new java.sql.Date(udate.getTime());
							
							Long bookingId = orderService.getBookingId(custId, phnnumber, noOfTrucks,truckId,hdate);
							System.out.println(" Booking Successful.......\n Your booking id::"+bookingId);
							
							
						}else{
							System.out.println("Enter the valid mobile number");
						}
						
						
					}
					else{
						System.out.println("Sorry!!!!!!!!!"+noOfTrucks+"are not available");
					}
					}
					else{
						System.out.println("Please Enter the valid Truck Id");
					}
					}
					else{
						System.out.println("Enter the valid Id format ex:A111111");
					}
					break;
					case 2:
					
					System.exit(0);
					break;
				default:
					System.out.println("Enter valid options");
				}
			}catch(NumberFormatException | ParseException |InputMismatchException e){
				//e.printStackTrace();
				scanner.nextLine();
				System.out.println("Please enter a numeric value, try again");
			}
	}
	}
	

}
