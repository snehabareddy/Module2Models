package com.capgemini.TransportTruck.dao;

public class QueryMapper {
	
	public static final String VIEW_TRUCK_DETAILS="SELECT * FROM TruckDetails";
	public static final String NUMOF_TRUCK_AVAIL = "SELECT availableNos from TruckDetails where truckId = ?";
	public static final String BOOKING_ID="SELECT booking_id_seq.CURRVAL from dual";
	public static final String ADD_CUSTOMER_DETAILS="INSERT INTO BookingDetails VALUES(booking_id_seq.NEXTVAL,?,?,?,?,?)";
	public static final String TRUCK_QUANTITY_UPDATE="UPDATE TruckDetails set availableNos=availableNos-? where truckId =?";
	public static final String IS_VALID_ID = "select * from TruckDetails where truckId = ?";
}
