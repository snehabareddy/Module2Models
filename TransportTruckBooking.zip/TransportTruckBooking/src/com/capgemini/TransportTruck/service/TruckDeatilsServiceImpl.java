package com.capgemini.TransportTruck.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.dao.ITruckdetails;
import com.capgemini.TransportTruck.dao.TruckdetailsDao;
import com.capgemini.TransportTruck.exception.TransportTruckException;


public class TruckDeatilsServiceImpl implements ITruckDeatilsService{
	
	ITruckdetails truckdao = new TruckdetailsDao();

	@Override
	public List<TruckDetails> getTruckDetails() throws TransportTruckException {
		List<TruckDetails> truckDetails=  truckdao.getTruckDetails();
		return truckDetails;
		
	}

	@Override
	public Integer trucksAvailable(Integer truckId)
			throws TransportTruckException {
		
		return truckdao.trucksAvailable(truckId) ;
	}

	@Override
	public Long getBookingId(String custId, Long custMobile,
			Integer noOfTrucks,Integer truckId,Date date)
			throws TransportTruckException {
		truckdao.updateQuantity(noOfTrucks,truckId);
		
		return truckdao.getBookingId(custId, custMobile, noOfTrucks,truckId,date);
	}

	@Override
	public Boolean isValidId(Integer truckId) throws TransportTruckException {
		// TODO Auto-generated method stub
		return truckdao.isValidId(truckId);
	}

}
