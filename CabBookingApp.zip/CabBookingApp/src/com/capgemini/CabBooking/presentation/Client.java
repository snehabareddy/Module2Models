package com.capgemini.CabBooking.presentation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.capgemini.CabBooking.exception.CabBookingException;
import com.capgemini.CabBooking.service.CabRequestDetailsServiceImpl;
import com.capgemini.CabBooking.service.ICabRequestDetailsService;
import com.capgemini.CabBooking.service.Validator;

public class Client {
	private static ICabRequestDetailsService cabdao = new CabRequestDetailsServiceImpl();
	private static Validator validator = new Validator();
	private static Scanner scanner = new Scanner(System.in);
	private static ICabRequestDetailsService servicedao = new CabRequestDetailsServiceImpl();
	public static void main(String[] args) throws ParseException,CabBookingException{
	Integer option=null;
	while(true) {
	System.out.println("=========Booking Application========");
	System.out.println("1. Raise Cab Request");
	System.out.println("2. View Cab Request Status");
	System.out.println("3. Exit");
	System.out.println("Enter your choice");
	option=scanner.nextInt();
	switch(option) {
	case 1:
		addRequest();
		break;
	case 2:
		viewRequest();
		break;
	case 3:
		System.exit(0);
		break;
	default:
	System.out.println("Enter valid option within 1 and 3");
		break;
	}
	}
}
	private static void viewRequest() {
		// TODO Auto-generated method stub
		
	}
	private static void addRequest() throws ParseException, CabBookingException {
		System.out.println("Please,Enter your Name");
		String name = scanner.next();
		
		if(validator.isValidCustomerName(name)){
			System.out.println("Please,Enter your Phone Number");
			Long phnnumber = scanner.nextLong();
			
			if(validator.isValidCustomerMobile(phnnumber)){
				
				System.out.println("Enter the date of Request");
				String date = scanner.next();
				DateFormat dateformat = new SimpleDateFormat("dd/MM/YYYY");
				java.util.Date udate = dateformat.parse(date);
				java.sql.Date hdate = new java.sql.Date(udate.getTime());
				
				System.out.println("Please enter the pickup address");
				String pickupaddress = scanner.next();
				
				System.out.println("Please enter the Pincode");
				Integer pincode = scanner.nextInt();
				if(validator.isValidPincode(pincode)){
					
					System.out.println("Enter the Droping Address");
					String dropaddress = scanner.next();
					
					Long bookingId = servicedao.getBookingId(name, phnnumber, hdate, pickupaddress, pincode, dropaddress);
					System.out.println("Booking Successfu!!!!!!!!!!!!! \n Your Booking Id is: "+bookingId);
					Long cabNumber = servicedao.getCabNumber(bookingId);
					System.out.println("\nYour Cab Number :  "+cabNumber+"\n");
				}else{
					System.out.println("Please enter the valid Pincode...Pincode is of 6 digits");
					}
				
			}else{
				System.out.println("Please enter valid Phone Number");
			}
		}else{
			System.out.println("Name should start with Capital Letter");
		}
	}

}
