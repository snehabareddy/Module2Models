package com.capgemini.CabBooking.presentation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.CabBooking.exception.CabBookingException;
import com.capgemini.CabBooking.service.CabRequestDetailsServiceImpl;
import com.capgemini.CabBooking.service.ICabRequestDetailsService;
import com.capgemini.CabBooking.service.Validator;


public class Client {
	private static ICabRequestDetailsService cabdao = new CabRequestDetailsServiceImpl();
	private static Validator validator = new Validator();
	private static Scanner scanner = new Scanner(System.in);
	private static ICabRequestDetailsService servicedao = new CabRequestDetailsServiceImpl();
	private static Long bookingId=null;
	private static String pickupaddress = null;
	private static String dropaddress = null;

	public static void main(String[] args) throws ParseException,CabBookingException{
		Integer option=null;
		while(true) {
			System.out.println("=========Booking Application========");
			System.out.println("1. Raise Cab Request");
			System.out.println("2. View Cab Request Status");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			try{
				option=scanner.nextInt();

				switch(option) {
				case 1:
					addRequest();
					break;
				case 2:
					viewRequest();
					break;
				case 3:
					System.exit(0);
					break;
				default:
					System.out.println("Enter valid option within 1 and 3");
					break;
				}
			}catch(InputMismatchException e){
				System.out.println("please enter valid choice");
				scanner.nextLine();
			}
		}
	}
	private static void viewRequest() throws CabBookingException {
		Long cabNumber = servicedao.getCabNumber(bookingId);
		System.out.println("\nYour Cab Number :  "+cabNumber+"\n");
		System.out.println("pickupaddress::" + pickupaddress);
		System.out.println("Drop address ::"+dropaddress);


	}
	private static void addRequest() throws ParseException, CabBookingException {
		System.out.println("Please,Enter your Name");
		try{
			String name = scanner.next();

			if(validator.isValidCustomerName(name)){
				System.out.println("Please,Enter your Phone Number");
				Long phnnumber = scanner.nextLong();

				if(validator.isValidCustomerMobile(phnnumber)){

					System.out.println("Enter the date of Request");
					String date = scanner.next();
					DateFormat dateformat = new SimpleDateFormat("dd/MM/YYYY");
					try{
						java.util.Date udate = dateformat.parse(date);
						java.sql.Date hdate = new java.sql.Date(udate.getTime());

						System.out.println("Please enter the pickup address");
						pickupaddress = scanner.next();

						System.out.println("Please enter the Pincode");
						Integer pincode = null;

						try{
							pincode=scanner.nextInt();
						if(validator.isValidPincode(pincode)){

							System.out.println("Enter the Droping Address");
							dropaddress = scanner.next();

							bookingId = servicedao.getBookingId(name, phnnumber, hdate, pickupaddress, pincode, dropaddress);
							System.out.println("Booking Successfu!!!!!!!!!!!!! \n Your Booking Id is: "+bookingId);

						}else{
							System.out.println("Please enter the valid Pincode...Pincode is of 6 digits");
						}
						}
						catch(InputMismatchException e){
							System.out.println("Pincode contains digits");
							scanner.next();
						}
					}catch(ParseException e){
						System.out.println("enter valid date");
					}

					}
				else{
					System.out.println("Please enter valid Phone Number");
				}
			}else{
				System.out.println("Name should start with Capital Letter");

			}
		}catch(InputMismatchException e){
			//System.out.println("please enter valid name contain only strings");
			scanner.next();
		}
	
	}
}
