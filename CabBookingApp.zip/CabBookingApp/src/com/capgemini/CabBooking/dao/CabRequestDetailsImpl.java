package com.capgemini.CabBooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.CabBooking.bean.CabRequestDetails;
import com.capgemini.CabBooking.exception.CabBookingException;
import com.capgemini.CabBooking.utility.DBConnection;




public class CabRequestDetailsImpl implements ICabRequestDetails {

	@Override
	public Long getBookingId(String cname, Long phonenum, Date dateOfrequest,
			String pickupaddress, Integer pincode, String dropaddress)
			throws CabBookingException {
		
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setString(1,cname);
			preparedStatement.setLong(2,phonenum);
			preparedStatement.setDate(3,dateOfrequest);
			preparedStatement.setString(4,pickupaddress);
			preparedStatement.setInt(5,pincode);
			preparedStatement.setString(6,dropaddress);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				ResultSet rs= statement.executeQuery(QueryMapper.BOOKING_ID);
				if(rs.next()){
					Long bookingId = rs.getLong(1);
					
					return bookingId;
				}
			}
			
			
		}catch(Exception e){
			throw new CabBookingException("unable to add details");
		}
		
		return null;
	}

	@Override
	public Long getCabNumber(Long requestId) throws CabBookingException {

		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.CAB_NUMBER);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setDouble(1,requestId );
			ResultSet resultSet=preparedStatement.executeQuery();
			//List<CabRequestDetails> cabList=new ArrayList<>();
			if(resultSet.next()){
				Long id=resultSet.getLong(1);
				return id;
				
			}
			
			
		}catch(Exception e){
			throw new CabBookingException("unable to load details");
		}
		return null;
	}

	

}
