package com.capgemini.CabBooking.dao;

public class QueryMapper {
	
	public static final String ADD_CUSTOMER_DETAILS="INSERT INTO  cabdetails VALUES(requestId_seq.NEXTVAL,?,?,?,?,?,cabnumber_seq.NEXTVAL,?)";
	public static final String BOOKING_ID="SELECT requestId_seq.CURRVAL from dual";
	public static final String CAB_NUMBER="SELECT cabnumber from cabdetails where requestid = ?";
}
