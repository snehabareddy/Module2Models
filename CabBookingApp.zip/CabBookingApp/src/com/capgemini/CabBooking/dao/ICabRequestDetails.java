package com.capgemini.CabBooking.dao;

import java.sql.Date;
import java.util.List;

import com.capgemini.CabBooking.bean.CabRequestDetails;
import com.capgemini.CabBooking.exception.CabBookingException;
;



public interface ICabRequestDetails {
	
	public Long getBookingId(String cname,
			Long phonenum,Date dateOfrequest ,String pickupaddress ,Integer pincode,String dropaddress) throws CabBookingException;
	public Long getCabNumber(Long requestId) throws CabBookingException;
	public CabRequestDetails getRequest(int requestId) throws CabBookingException;
}
