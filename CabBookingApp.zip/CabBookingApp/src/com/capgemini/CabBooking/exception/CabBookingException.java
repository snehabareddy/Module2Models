package com.capgemini.CabBooking.exception;

public class CabBookingException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private String message;
	public CabBookingException() {
		super();
	}
	public CabBookingException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	
	@Override
	public String toString() {
		return "TransportTruckException [message=" + message + "]";
	}
	
	

}
