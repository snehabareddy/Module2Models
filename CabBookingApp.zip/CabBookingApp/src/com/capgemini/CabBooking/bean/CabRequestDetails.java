package com.capgemini.CabBooking.bean;
import java.sql.Date;

public class CabRequestDetails {
	private Integer requestId;
	private String customerName;
	private String phoneNumber;
	private Date dateOfRequest;
	private Long cabNumber;
	private String pickupAddress;
	private String dropAddress;
	private Integer pincode;
	
	public CabRequestDetails() {
		super();
	}
	
	public CabRequestDetails(Integer requestId, String customerName,
			String phoneNumber, Date dateOfRequest, Long cabNumber,
			String pickupAddress, String dropAddress, Integer pincode) {
		super();
		this.requestId = requestId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.dateOfRequest = dateOfRequest;
		this.cabNumber = cabNumber;
		this.pickupAddress = pickupAddress;
		this.dropAddress = dropAddress;
		this.pincode = pincode;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getDateOfRequest() {
		return dateOfRequest;
	}

	public void setDateOfRequest(Date dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}

	public Long getCabNumber() {
		return cabNumber;
	}

	public void setCabNumber(Long cabNumber) {
		this.cabNumber = cabNumber;
	}

	public String getPickupAddress() {
		return pickupAddress;
	}

	public void setPickupAddress(String pickupAddress) {
		this.pickupAddress = pickupAddress;
	}

	public String getDropAddress() {
		return dropAddress;
	}

	public void setDropAddress(String dropAddress) {
		this.dropAddress = dropAddress;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "CabRequestDetails [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", cabNumber="
				+ cabNumber + ", pickupAddress=" + pickupAddress
				+ ", dropAddress=" + dropAddress + ", pincode=" + pincode + "]";
	}
	
	
}
