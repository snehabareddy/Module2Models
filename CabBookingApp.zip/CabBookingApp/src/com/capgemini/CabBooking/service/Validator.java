package com.capgemini.CabBooking.service;

import java.util.regex.Pattern;



public class Validator {
public Validator(){
		
	}
public Boolean isValidCustomerName(String name){
	String regex1= "^[A-Z]{1}[a-zA-Z\\s]{0,19}$";
	//return Pattern.matches(regex,name);
	return name.matches(regex1);
}
public Boolean isValidCustomerMobile(Long phnnumber){
	String regex="^[1-9][0-9]{9}$";
	 String mobile= Long.toString(phnnumber);

	return Pattern.matches(regex,mobile);
}
public Boolean isValidPincode(Integer pincode){
	String regex = "^[1-9]{1}[0-9]{5}$";
	String pin = Integer.toString(pincode);
	System.out.println("Hello");
	return Pattern.matches(regex, pin);
	

}
}

