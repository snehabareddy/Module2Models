package com.capgemini.CabBooking.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.CabBooking.dao.CabRequestDetailsImpl;
import com.capgemini.CabBooking.dao.ICabRequestDetails;
import com.capgemini.CabBooking.exception.CabBookingException;




public class CabRequestDetailsServiceImpl implements ICabRequestDetailsService {
	
	ICabRequestDetails cabdao = new CabRequestDetailsImpl();

	@Override
	public Long getBookingId(String cname, Long phonenum, Date dateOfrequest,
			String pickupaddress, Integer pincode, String dropaddress)
			throws CabBookingException {
		
				return cabdao.getBookingId(cname, phonenum, dateOfrequest, pickupaddress, pincode, dropaddress);
		
	}

	@Override
	public Long getCabNumber(Long requestId) throws CabBookingException {
		
		return cabdao.getCabNumber(requestId);
	}

}
