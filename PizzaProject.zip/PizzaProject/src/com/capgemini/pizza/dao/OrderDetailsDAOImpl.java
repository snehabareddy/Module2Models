package com.capgemini.pizza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.bean.PizzaOrder;
import com.capgemini.pizza.exception.PizzaException;
import com.capgemini.pizza.util.DBConnection;

public class OrderDetailsDAOImpl implements IOrderDetailsDAO{

	@Override
	public PizzaOrder getOrderDetails(Long orderId) throws PizzaException {
	
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DISPLAY_ORDER);
				){
			preparedStatement.setLong(1, orderId);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				
				PizzaOrder order=new PizzaOrder();
				populateOrder(order,resultSet);
				return order;
			}
			
		}catch(PizzaException e){
			throw new PizzaException("Your customer id doesnot have any available orders to display");
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}

	private void populateOrder(PizzaOrder order, ResultSet resultSet) throws SQLException {
		order.setCustomerId(resultSet.getLong("cid"));
		order.setOrderId(resultSet.getLong("orderid"));
		order.setTotalPrice(resultSet.getDouble("total_price"));
		order.setpDate(resultSet.getDate("pdate"));

	}

	@Override
	public Long placeOrder(Long customerId, Double totalPrice)
			throws PizzaException, SQLException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_ORDER_DETAILS);
				Statement statement =connection.createStatement();
				){
			preparedStatement.setLong(1, customerId);
			preparedStatement.setDouble(2,totalPrice);
			int n=preparedStatement.executeUpdate();
		
			
			if(n>0){
				{
				ResultSet rs= statement.executeQuery(QueryMapper.ORDER_ID);
				if(rs.next()){
					Long orderId = rs.getLong(1);
					
					return orderId;
				}
				}
			
			}
		}catch(PizzaException e){

		}

	
	return null;
}

	@Override
	public Integer updateQuantity(String pname, Integer quantity)
			throws PizzaException {
		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.PIZZA_QUANTITY_UPDATE);

				){
			preparedStatement.setInt(1, quantity);
			preparedStatement.setString(2, pname);

			int n=preparedStatement.executeUpdate();
			if(n>0){
				return n;
			}
		}catch(SQLException e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();

		}catch(Exception e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return null;

	}

	@Override
	public boolean isValidOrderId(Long orderId) throws PizzaException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.CHECK_VALID_ORDERID);
				){
			preparedStatement.setLong(1, orderId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				return true;
			}
			//myMobDAOLogger.error("Enter valid mobile id");
			return false;
		}catch(SQLException e){
			//myMobDAOLogger.error(e.getMessage());
			throw new PizzaException("Technical Error! Contact to log ");
		}

	
	}

	@Override
	public List<Pizza> getPizzaDetails() throws PizzaException {
int pizzaCount = 0;
		
		try(Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery(QueryMapper.VIEW_ALL_PIZZAS);
			List<Pizza> pizzaList = new ArrayList<>();
			while(resultSet.next()){
				
				pizzaCount++;
				Pizza pizza = new Pizza();
				populatePizza(pizza,resultSet);
				pizzaList.add(pizza);
				
			}
			if(pizzaCount!=0){
				
				return pizzaList;
			}else{
				return null;
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
		return null;
	}

	private void populatePizza(Pizza pizza, ResultSet resultSet) throws SQLException {
		
		pizza.setPizzaName(resultSet.getString("p_nmae"));
		pizza.setPizzaPrice(resultSet.getDouble("p_price"));
		pizza.setQuantity(resultSet.getInt("quantity"));

	}

		
	}



