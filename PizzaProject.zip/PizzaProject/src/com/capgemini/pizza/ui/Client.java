package com.capgemini.pizza.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.pizza.bean.Customer;
import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.bean.PizzaOrder;
import com.capgemini.pizza.exception.PizzaException;
import com.capgemini.pizza.service.CustomerService;
import com.capgemini.pizza.service.ICustomerService;
import com.capgemini.pizza.service.IOrderDetailsService;
import com.capgemini.pizza.service.OrderDetailsServiceImpl;
import com.capgemini.pizza.service.Validator;

public class Client {
	private static Scanner scanner=new Scanner(System.in);
private static Customer customer = new Customer();
	private static IOrderDetailsService orderService = new OrderDetailsServiceImpl();
	private static ICustomerService customerService = new CustomerService();
	private static Validator validator = new Validator();
	public static void main(String[] args) throws PizzaException {
		//scanner.useDelimiter("\n");
		Double pizzaToppingsPrice=0.0;
		Double basePizzaPrice=0.00;
		int option;
		//String ans="";
	while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Pizza Order System  ");
			System.out.println("_______________________________\n");


			System.out.println("1.Show Pizzas");
			System.out.println("2.Place Order");
			System.out.println("3.Display Your Order");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			option = scanner.nextInt();

			try {

				switch (option) {
				case 1:
					System.out.println("Available Items: ");
					List<Pizza> pizzaDetails=orderService.getPizzaDetails();
					Iterator<Pizza> iterator= pizzaDetails.iterator();
					while(iterator.hasNext()){
						System.out.println(iterator.next());
					} 
					
					break;
				case 2:
					System.out.println("Enter customer mobile number");
					Long phnnumber = scanner.nextLong();
					scanner.nextLine();
					System.out.println("Enter customer name:");
					String cname = scanner.next();
					System.out.println("Enter customer Address");
					String address = scanner.next();
					System.out.println("Select the option of pizza you want to have:"
							+ "1.Margherita"+
							"2.Crudo"+
							"3.Romana"+
							"4.Montanara"+
							"5.Americana");
					
					Integer pizza = scanner.nextInt();
					switch(pizza){
					case 1:
						basePizzaPrice=300.00;
						break;
					case 2:
						basePizzaPrice = 400.00;
						break;
					case 3:
						basePizzaPrice=350.00;
						break;
					case 4:
						basePizzaPrice = 550.00;
						break;
					case 5:
						basePizzaPrice =750.00;
						break;
					default:
						System.out.println("Enter valid option[1-5]");
					}
					System.out.println("Enter the Pizza Topping preffered:"
							+ "Capsicum,"+"\n"
							+ "mushroom,"+"\n"
							+ "Jalapeno,"+"\n"
							+ "Paneer");
					String topping=scanner.next();
					switch (topping) {
					case "Capsicum":
						pizzaToppingsPrice=30.0;
						break;
					case "MushRoom":
						pizzaToppingsPrice=50.0;
						break;
					case "Jalapeno":
						pizzaToppingsPrice=70.0;
						break;

					case "Paneer":
						pizzaToppingsPrice=85.0;
						break;
						
					default:
						System.out.println("Preffered Pizza Toppings are Invalid");
						
					}//end of innerswitch
					System.out.println("Enter the quantity of required mobileid");
					Integer quantity=scanner.nextInt();
					
					Double totalPrice=(quantity*basePizzaPrice) + pizzaToppingsPrice;
					System.out.println("Price:(To be calculated :Rs "+ quantity*basePizzaPrice + " + " + pizzaToppingsPrice + "("
							+ topping + ")=" + totalPrice);
					if(validator.isValidCustomerName(cname)){
						//System.out.println("1");
						if(validator.isValidCustomerMobile(phnnumber)){
							//System.out.println("2");
							Long customerId=customerService.addCustomerDetails(cname, address, phnnumber, totalPrice,quantity);
							System.out.println("Customer id: "+customerId);
						
							Long orderId= orderService.placeOrder(customerId, totalPrice,quantity);
							//System.out.println("order");
							//PizzaOrder order=orderService.getOrderDetails(orderId);
							System.out.println("Your order is placed...");
							System.out.println("Your order id is: "+orderId);
						}else{
							System.out.println("Enter valid phone number");
						}
					}else{
						System.out.println("Enter valid customer name");
					}
					break;	

				case 3:
					System.out.println("Please enter your order id:");
					Long orderid = scanner.nextLong();
					if(orderService.isValidOrderId(orderid)){
						PizzaOrder order = orderService.getOrderDetails(orderid);
						System.out.println("Customer ID: "+order.getCustomerId()+"\n"+
											"Order id: "+order.getOrderId()+"\n"+
											"Order Date: "+order.getpDate()+"\n"+
											"Total Price: "+order.getTotalPrice());
					}
					break;
				case 4:
					
					System.exit(0);
					break;
				default:
					System.out.println("Enter valid options");


				}//end of switch


			}catch(Exception e){

			}
			
			
		}//end of while
	}
}

