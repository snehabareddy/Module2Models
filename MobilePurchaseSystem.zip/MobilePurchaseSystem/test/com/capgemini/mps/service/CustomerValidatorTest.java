package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class CustomerValidatorTest {

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Ravi Kumar"));
	}

	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Ravi Kumar XXXXXXXXXX"));
	}
	
	@Test
	public void testIsValidEmail() {
		assertTrue(new CustomerValidator().isValidEmail("ravi@capgemini.com"));
	}
	
	@Test
	public void testIsNotValidEmail() {
		assertFalse(new CustomerValidator().isValidEmail("ravi@capgemini"));
	}

	
	@Test
	public void testIsValidPhoneNumber() {
		assertTrue(new CustomerValidator().isValidPhoneNumber(9898989898L));
	}
	
	@Test
	public void testIsInValidPhoneNumber() {
		assertFalse(new CustomerValidator().isValidPhoneNumber(12345L));
	}

}
