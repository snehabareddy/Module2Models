package com.cg.frs.ui;

import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {
	private static Scanner scanner = new Scanner(System.in);
	private static FlatRegistrationDTO flat= new FlatRegistrationDTO();
	private static IFlatRegistrationService flatService = new FlatRegistrationServiceImpl();

	public static void main(String[] args) throws FlatRegistrationException {
		int option;
		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Real Estate Registration Service ");
			System.out.println("_________________________________________\n");


			System.out.println("1.Register Flat");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			option = scanner.nextInt();
			try{
				switch(option){
				case 1:
					System.out.println("Existing owner IDs are:-"+flatService.getOwnerIds());
					System.out.println("Please enter your owner id from above list:");
					Integer ownerid=scanner.nextInt();
					flat.setOwner_id(ownerid);
					System.out.println("Select Flat Type(1:1BHK 2:2BHK)");
					Integer flattype = scanner.nextInt();
					flat.setFlat_type(flattype);
					System.out.println("Enter flat area in sq.ft:");
					Integer area=scanner.nextInt();
					flat.setFlat_area(area);
					System.out.println("Enter desired rent amount:");
					Double rent = scanner.nextDouble();
					flat.setRent_amount(rent);
					System.out.println("Enter desired deposit amount");
					Double amount = scanner.nextDouble();
					flat.setDeposit_amount(amount);
					
					FlatRegistrationDTO registeredFlat = new FlatRegistrationDTO(ownerid,flattype,area,rent,amount);
					registeredFlat = flatService.registerFalt(flat);
					long id = registeredFlat.getFlat_reg_no();
					System.out.println("Flat successfully registered. Registration id: "+id);
				break;
				case 2:
					System.exit(0);
					break;
				default:
					System.out.println("Please enter valid options [1-2]");
				}
			}catch(Exception e){
				
				throw new FlatRegistrationException("Enter valid input");
				
			}
		}

		

	}

}
