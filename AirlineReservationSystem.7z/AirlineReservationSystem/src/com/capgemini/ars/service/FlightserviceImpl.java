package com.capgemini.ars.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.dao.FlightDaoImpl;
import com.capgemini.ars.dao.IFlightDao;
import com.capgemini.ars.exception.ARSException;

public class FlightserviceImpl implements IFlightservice{
	IFlightDao flightDAO=new FlightDaoImpl();

	@Override
	public void addFlight(FlightBean flight) throws ARSException {
		flightDAO.addFlight(flight);
		
	}

	@Override
	public Integer deleteFlight(String flightNo) throws ARSException {
		return flightDAO.deleteFlight(flightNo);
		
	}

	@Override
	public Integer updateFlight(String fno,String dtime,String atime) throws ARSException {
		
		return flightDAO.updateFlight(fno, dtime, atime);
	}

	@Override
	public List<FlightBean> getAllFlightDetails() throws ARSException {
	List<FlightBean> flightList = new ArrayList<>();
	flightList=flightDAO.getAllFlightDetails();
		return flightList;
	}

	@Override
	public List<FlightBean> getFlights(String dep_city, String arr_city,
			Date dep_date) throws ARSException {
		
		List<FlightBean> flightList = new ArrayList<>();
		flightList=flightDAO.getFlights(dep_city, arr_city, dep_date);
			return flightList;
	}

	@Override
	public FlightBean getFlightDetails(String flightno) throws ARSException {
		FlightBean flight = new FlightBean();
		flight = flightDAO.getFlightDetails(flightno);
		return flight;
	}

	@Override
	public Integer getFirstSeatOccupancy(String flightno) throws ARSException {
		Integer firstSeatAvailability=flightDAO.getFirstSeatOccupancy(flightno);
		return firstSeatAvailability;
	}

	@Override
	public Integer getBussSeatOccupancy(String flightno) throws ARSException {
		Integer bussSeatAvailability=flightDAO.getBussSeatOccupancy(flightno);
		return bussSeatAvailability;
	}

	@Override
	public boolean isValidFlightNo(String dep_city, String arr_city,
			Date dep_date, String flightno) throws ARSException {
		boolean bool=flightDAO.isValidFlightNo(dep_city, arr_city, dep_date, flightno);
		
		return bool;
	}

	@Override
	public Double firstClassFare(String flightno) throws ARSException {
		Double firstSeatFare = flightDAO.firstClassFare(flightno);
		return firstSeatFare;
	}

	@Override
	public Double bussClassFare(String flightno) throws ARSException {
		Double bussSeatFare = flightDAO.bussClassFare(flightno);
		return bussSeatFare;
		
	}

	@Override
	public Integer updateFirstClassSeats(String flightno, Integer no_of_Seats)
			throws ARSException {
		
		return flightDAO.updateFirstClassSeats(flightno, no_of_Seats);
	}

	@Override
	public Integer updateBussClassSeats(String flightno, Integer no_of_Seats)
			throws ARSException {
		
		return flightDAO.updateBussClassSeats(flightno, no_of_Seats);
	}

	@Override
	public List<Integer> occupancyDate(String flightno, Date fdate)
			throws ARSException {
		List<Integer> list=flightDAO.occupancyDate(flightno, fdate);
		return list;
	}

	@Override
	public List<String> occupancyCity(String depCity, String arrCity)
			throws ARSException {
		
		List<String> list=flightDAO.occupancyCity(depCity, arrCity);
		return list;
	}

	@Override
	public boolean isValidEmail(String email) throws ARSException {
		
		return flightDAO.isValidEmail(email);
	}

	@Override
	public boolean validFlight(String flightno) throws ARSException {
		
		return flightDAO.validFlight(flightno);
	}

}
