package com.capgemini.ars.dao;

import java.sql.Date;
import java.util.List;

import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.exception.ARSException;

public interface IFlightDao {
	public abstract void addFlight(FlightBean flight)throws ARSException;
	public abstract Integer deleteFlight(String flightNo) throws ARSException;
	public abstract  Integer updateFlight(String fno,String dtime,String atime)throws ARSException;
	public abstract List<FlightBean> getAllFlightDetails()throws ARSException;
	public abstract List<FlightBean> getFlights(String dep_city,String arr_city,Date dep_date)throws ARSException;
	public abstract FlightBean getFlightDetails(String flightno) throws ARSException;
	public abstract Integer getFirstSeatOccupancy(String flightno) throws ARSException;
	public abstract Integer getBussSeatOccupancy(String flightno) throws ARSException;
	public abstract boolean isValidFlightNo(String dep_city,String arr_city,Date dep_date,String flightno)throws ARSException;
	public abstract Double firstClassFare(String flightno)throws ARSException;
	public abstract Double bussClassFare(String flightno)throws ARSException;
	public abstract Integer updateFirstClassSeats(String flightno,Integer no_of_Seats)throws ARSException;
	public abstract Integer updateBussClassSeats(String flightno,Integer no_of_Seats)throws ARSException;
	public abstract List<Integer> occupancyDate(String flightno,Date fdate)throws ARSException;
	public abstract List<String> occupancyCity(String depCity,String arrCity) throws ARSException;
	public abstract boolean isValidEmail(String email)throws ARSException;
	public abstract boolean validFlight(String flightno)throws ARSException;
}
