package com.capgemini.ars.bean;

public class BookingBean {

		private Integer bookingId;
		private String custEmail;
		private Integer noOfPassengers;
		
		private String classType;
		private Double totalFare;
		private Integer seatNo;
		private String creditCardInfo;
		private String srcCity;
		private String destCity;
		private String flightno;
		
		public BookingBean() {
			super();
		}


		public BookingBean(Integer bookingId, String custEmail,
				Integer noOfPassengers, 
				String classType, Double totalFare, Integer seatNo,
				String creditCardInfo, String srcCity, String destCity,String flightno) {
			super();
			this.bookingId = bookingId;
			this.custEmail = custEmail;
			this.noOfPassengers = noOfPassengers;
			
			this.classType = classType;
			this.totalFare = totalFare;
			this.seatNo = seatNo;
			this.creditCardInfo = creditCardInfo;
			this.srcCity = srcCity;
			this.destCity = destCity;
			this.flightno=flightno;
		}


		public String getFlightno() {
			return flightno;
		}


		public void setFlightno(String flightno) {
			this.flightno = flightno;
		}


		public Integer getBookingId() {
			return bookingId;
		}


		public void setBookingId(Integer bookingId) {
			this.bookingId = bookingId;
		}


		public String getCustEmail() {
			return custEmail;
		}


		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}


		public Integer getNoOfPassengers() {
			return noOfPassengers;
		}


		public void setNoOfPassengers(Integer noOfPassengers) {
			this.noOfPassengers = noOfPassengers;
		}


	


		public String getClassType() {
			return classType;
		}


		public void setClassType(String classType) {
			this.classType = classType;
		}


		public Double getTotalFare() {
			return totalFare;
		}


		public void setTotalFare(Double totalFare) {
			this.totalFare = totalFare;
		}


		public Integer getSeatNo() {
			return seatNo;
		}


		public void setSeatNo(Integer seatNo) {
			this.seatNo = seatNo;
		}


		public String getCreditCardInfo() {
			return creditCardInfo;
		}


		public void setCreditCardInfo(String creditCardInfo) {
			this.creditCardInfo = creditCardInfo;
		}


		public String getSrcCity() {
			return srcCity;
		}


		public void setSrcCity(String srcCity) {
			this.srcCity = srcCity;
		}


		public String getDestCity() {
			return destCity;
		}


		public void setDestCity(String destCity) {
			this.destCity = destCity;
		}


		@Override
		public String toString() {
			return "BookingDetails"
					+ "BookingId: " + bookingId + 
					", MailID:"  + custEmail + ","
					+ "Total Passengers for this booking:" + noOfPassengers
					+ ", ClassType: " + classType +
					", Fare for current booking: " + totalFare
					+ ", SeatNumber:" + seatNo + ", "
					+ "CreditCardInfo: "+ creditCardInfo + ", "
					+ "Departure City: " + srcCity +
					", Arrival City"+ destCity 
					+ ", Booking flight no.: " + flightno;
		}


		
		
		
		
}
